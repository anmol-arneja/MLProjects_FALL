This file contains instructions on how to run the knn algorithm
******This code is implemented in Python*****
******Before running the code please check if you need to install some module in order to run it*****
***********There are two implementations of KNN, First implementation contains code for all the functions implemented by the team, The second implementation uses
already implemented methods in graphlab module in Python********

Running the first implementation

1.Open the folder knn_implement1
2.Inside it run the file knn.py

Running the second implementation
1.Open the folder knn_implement2
2.Run the file knn_implement2
3.For running this you have to register and install graphlab
4.You will get 30 days free trial license.
5.you may choose to download graphlab from here :
 https://dato.com/download/
